package com.dioclass.philipsdevweek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhilipsDevweekApplicationTests {

	@Test
	void contextLoads() {
	}

}
